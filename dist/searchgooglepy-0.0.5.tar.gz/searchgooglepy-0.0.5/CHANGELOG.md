# Changelog of QuickLinkJs:

- v0.0.1 Alpha A-1 {master} {
    - Inital Commit, Added module files into the repository.
}
- v0.0.2 Alpha A-1 {master} {
    - Added Some Feature !
}
- v0.0.3 Alpha A-1 {master} {
    - Updated Github / Pypi Docs :books: :octocat: !
    - Base Web-Documentation builded and hosted (not yet ready, sorry) !
}
- v0.0.4 Alpha B-2 {master} {
    - Updated Github / Pypi Docs: :books :octocat: !
    - Web-Documentation is now ready :books: !!
    - Fixed some bugs :bug: !
}
- v0.0.5 Alpha B-2 {master} {
    - Updated Web-Documentations :books: !!
        - Fixed some bugs :bug:
        - Added Automatic Light and Dark Mode !!
}
- v0.0.6 Alpha B-2 {master} {
    - Updated Github / Pypi Docs: :books: :octocat:
    - Added new features :fire: !
        - Added `search_shop` function :+1: !
        - Fixed some bugs :bug: !
    - Updated Web-Documentation :books: !
        - Fixed some bugs :bug: !
        - Added new features :fire: :100: !!
}