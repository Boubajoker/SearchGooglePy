echo "<!--SearchGooglePy Copyright (c) Boubajoker 2022. All right reserved. Project under MIT License. -->"
ls ./ --group-directories-first
bash start "./test.py"