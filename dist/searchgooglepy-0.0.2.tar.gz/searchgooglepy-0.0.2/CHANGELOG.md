# Changelog of QuickLinkJs:

- v0.0.1 Alpha A-1 {master} {
    - Inital Commit, Added module files into the repository.
}
- v0.0.2 Alpha A-1 {master} {
    - Added Some Feature !
}