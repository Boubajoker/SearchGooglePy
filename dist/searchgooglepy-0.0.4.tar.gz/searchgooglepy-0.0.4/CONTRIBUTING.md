# Contributing

## Module Contribution

For any contributions / modifications to the module go to:

- [`./searchgpy/__init__.py`](./searchgpy/__init__.py) file to modify the module's src file.

- [`./searchgpy/__init__.pyi`](./searchgpy/__init__.pyi) file to modify the module's declaration file.