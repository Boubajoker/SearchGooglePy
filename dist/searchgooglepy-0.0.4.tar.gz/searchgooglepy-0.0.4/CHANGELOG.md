# Changelog of QuickLinkJs:

- v0.0.1 Alpha A-1 {master} {
    - Inital Commit, Added module files into the repository.
}
- v0.0.2 Alpha A-1 {master} {
    - Added Some Feature !
}
- v0.0.3 Alpha A-1 {master} {
    - Updated Github / Pypi Docs :books: :octocat: !
    - Base Web-Documentation builded and hosted (not yet ready, sorry) !
}
- v0.0.4 Alpha B-2 {master} {
    - Updated Github / Pypi Docs: :books :octocat: !
    - Web-Documentation is now ready :books: !!
    - Fixed some bugs :bug: !
}